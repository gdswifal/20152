-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 23-Out-2015 às 22:13
-- Versão do servidor: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paonamao`
--
CREATE DATABASE IF NOT EXISTS `paonamao` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `paonamao`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `companies`
--

DROP TABLE IF EXISTS `companies`;
CREATE TABLE IF NOT EXISTS `companies` (
  `comp_id` int(10) unsigned NOT NULL,
  `comp_name` varchar(255) DEFAULT NULL,
  `comp_location` varchar(45) DEFAULT NULL,
  `comp_email` varchar(255) DEFAULT NULL,
  `comp_telephone` bigint(20) DEFAULT NULL,
  `comp_password` varchar(100) DEFAULT NULL,
  `comp_cnpj` varchar(14) DEFAULT NULL,
  `comp_address` varchar(255) DEFAULT NULL,
  `comp_logo` varchar(40) DEFAULT NULL,
  `comp_phrase` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `favorites`
--

DROP TABLE IF EXISTS `favorites`;
CREATE TABLE IF NOT EXISTS `favorites` (
  `favo_id` int(10) unsigned NOT NULL,
  `Users_user_id` int(10) unsigned NOT NULL,
  `favo_companyid` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `orde_id` int(10) unsigned NOT NULL,
  `Users_user_id` int(10) unsigned NOT NULL,
  `Companies_comp_id` int(10) unsigned NOT NULL,
  `orde_price` float(5,2) DEFAULT NULL,
  `orde_status` int(10) unsigned DEFAULT '0',
  `orde_stars` int(10) unsigned DEFAULT NULL,
  `orde_address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `orders_has_products`
--

DROP TABLE IF EXISTS `orders_has_products`;
CREATE TABLE IF NOT EXISTS `orders_has_products` (
  `Orders_Companies_comp_id` int(10) unsigned NOT NULL,
  `Orders_Users_user_id` int(10) unsigned NOT NULL,
  `Orders_orde_id` int(10) unsigned NOT NULL,
  `Products_Companies_comp_id` int(10) unsigned NOT NULL,
  `Products_prod_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `prod_id` int(10) unsigned NOT NULL,
  `Companies_comp_id` int(10) unsigned NOT NULL,
  `prod_description` varchar(255) DEFAULT NULL,
  `prod_production` date DEFAULT NULL,
  `prod_expiration` int(10) unsigned DEFAULT NULL,
  `prod_price` decimal(10,2) DEFAULT NULL,
  `prod_amount` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_telephone` bigint(11) unsigned NOT NULL,
  `user_password` varchar(100) DEFAULT NULL,
  `user_profile_photo` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`comp_id`),
  ADD UNIQUE KEY `comp_cnpj` (`comp_cnpj`),
  ADD UNIQUE KEY `comp_email` (`comp_email`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`favo_id`),
  ADD KEY `Favorites_FKIndex1` (`Users_user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orde_id`,`Users_user_id`,`Companies_comp_id`),
  ADD KEY `Orders_FKIndex1` (`Users_user_id`),
  ADD KEY `Orders_FKIndex2` (`Companies_comp_id`);

--
-- Indexes for table `orders_has_products`
--
ALTER TABLE `orders_has_products`
  ADD PRIMARY KEY (`Orders_Companies_comp_id`,`Orders_Users_user_id`,`Orders_orde_id`,`Products_Companies_comp_id`,`Products_prod_id`),
  ADD KEY `Orders_has_Products_FKIndex1` (`Orders_orde_id`,`Orders_Users_user_id`,`Orders_Companies_comp_id`),
  ADD KEY `Orders_has_Products_FKIndex2` (`Products_prod_id`,`Products_Companies_comp_id`),
  ADD KEY `Products_Companies_comp_id` (`Products_Companies_comp_id`),
  ADD KEY `Orders_Users_user_id` (`Orders_Users_user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_id`,`Companies_comp_id`),
  ADD KEY `Products_FKIndex1` (`Companies_comp_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_mail` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `comp_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `favo_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orde_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prod_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
