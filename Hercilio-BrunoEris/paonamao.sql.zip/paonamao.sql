-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 11-Out-2015 às 17:34
-- Versão do servidor: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `paonamao`
--
CREATE DATABASE IF NOT EXISTS `paonamao` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `paonamao`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
`comp_id` int(10) unsigned NOT NULL,
  `comp_name` varchar(255) DEFAULT NULL,
  `comp_location` varchar(45) DEFAULT NULL,
  `comp_email` varchar(255) DEFAULT NULL,
  `comp_telephone` bigint(20) DEFAULT NULL,
  `comp_password` varchar(100) DEFAULT NULL,
  `comp_cnpj` varchar(14) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `companies`
--

INSERT INTO `companies` (`comp_id`, `comp_name`, `comp_location`, `comp_email`, `comp_telephone`, `comp_password`, `comp_cnpj`) VALUES
(22, 'Via Dupla', '-9.646072 -35.700229', 'contato@viaduplacalcados.com.br', 8233771400, '$2a$08$GDSWHBpaonamao7psi201uaNweu7JXeRC5HNiOLjDseVyelnsrxfK', '08328675000176');

-- --------------------------------------------------------

--
-- Estrutura da tabela `favorites`
--

CREATE TABLE IF NOT EXISTS `favorites` (
`favo_id` int(10) unsigned NOT NULL,
  `Users_user_id` int(10) unsigned NOT NULL,
  `favo_companyid` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
`orde_id` int(10) unsigned NOT NULL,
  `Users_user_id` int(10) unsigned NOT NULL,
  `Companies_comp_id` int(10) unsigned NOT NULL,
  `orde_price` float(5,2) DEFAULT NULL,
  `orde_status` int(10) unsigned DEFAULT '0',
  `orde_stars` int(10) unsigned DEFAULT NULL,
  `orde_adress` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `orders_has_products`
--

CREATE TABLE IF NOT EXISTS `orders_has_products` (
  `Orders_Companies_comp_id` int(10) unsigned NOT NULL,
  `Orders_Users_user_id` int(10) unsigned NOT NULL,
  `Orders_orde_id` int(10) unsigned NOT NULL,
  `Products_Companies_comp_id` int(10) unsigned NOT NULL,
  `Products_prod_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`prod_id` int(10) unsigned NOT NULL,
  `Companies_comp_id` int(10) unsigned NOT NULL,
  `prod_description` varchar(255) DEFAULT NULL,
  `prod_production` date DEFAULT NULL,
  `prod_expiration` int(10) unsigned DEFAULT NULL,
  `prod_price` float(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`user_id` int(10) unsigned NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_mail` varchar(255) DEFAULT NULL,
  `user_telephone` bigint(11) unsigned NOT NULL,
  `user_password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_mail`, `user_telephone`, `user_password`) VALUES
(4, 'Teste', 'teste@teste', 123, '$2a$08$GDSWHBpaonamao7psi201u51h416vZUgoVOaCCKr1vIfi27Rfd4ua'),
(5, 'Test', 'test@test', 123456, '$2a$08$GDSWHBpaonamao7psi201u51h416vZUgoVOaCCKr1vIfi27Rfd4ua'),
(6, 'Hudw aa adshuo', 'teste@teste.com', 88888888888, '$2a$08$GDSWHBpaonamao7psi201u8wyfDR3ghppDYfv8TeOEkmEc/7sSC6G'),
(16, 'Pedro augusto', 'pedroaugusto@gmail.com', 82999999999, '$2a$08$GDSWHBpaonamao7psi201uW/.HxdRvmZ5.jJhBnovhaPlWvtifuEe'),
(29, 'Hercilio Júnior', 'hercilio@junior.com', 82999260358, '$2a$08$GDSWHBpaonamao7psi201u37T1V2K2n8OJKK0qWq7SbgQduDq4H/u'),
(30, 'Hercilio Júnior', 'hercilio.master@gmail.com', 82999260358, '$2a$08$GDSWHBpaonamao7psi201u37T1V2K2n8OJKK0qWq7SbgQduDq4H/u'),
(31, 'Caroline Stephanie', 'carol@stephanie.com', 99999999999, '$2a$08$GDSWHBpaonamao7psi201umtJ4OoeYoP0mkVYvjghRy3bWQOI.QI2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
 ADD PRIMARY KEY (`comp_id`), ADD UNIQUE KEY `comp_cnpj` (`comp_cnpj`), ADD UNIQUE KEY `comp_email` (`comp_email`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
 ADD PRIMARY KEY (`favo_id`), ADD KEY `Favorites_FKIndex1` (`Users_user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
 ADD PRIMARY KEY (`orde_id`,`Users_user_id`,`Companies_comp_id`), ADD KEY `Orders_FKIndex1` (`Users_user_id`), ADD KEY `Orders_FKIndex2` (`Companies_comp_id`);

--
-- Indexes for table `orders_has_products`
--
ALTER TABLE `orders_has_products`
 ADD PRIMARY KEY (`Orders_Companies_comp_id`,`Orders_Users_user_id`,`Orders_orde_id`,`Products_Companies_comp_id`,`Products_prod_id`), ADD KEY `Orders_has_Products_FKIndex1` (`Orders_orde_id`,`Orders_Users_user_id`,`Orders_Companies_comp_id`), ADD KEY `Orders_has_Products_FKIndex2` (`Products_prod_id`,`Products_Companies_comp_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`prod_id`,`Companies_comp_id`), ADD KEY `Products_FKIndex1` (`Companies_comp_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`user_id`), ADD UNIQUE KEY `user_mail` (`user_mail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
MODIFY `comp_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
MODIFY `favo_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
MODIFY `orde_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
MODIFY `prod_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
